// tb_speed_pi.v — 속도 PI 폐루프 자체 점검 테스트벤치
// 1차 지연 모델 모터: speed[k] = 0.8*speed[k-1] + 0.2*(duty/PERIOD)*MAX_SPEED
// WINDOW_CYCLES=1000 (시뮬레이션 단축)
// 검사 항목:
//   CHECK1: IP_ID 레지스터 (0x53504931)
//   CHECK2: IP_VER 레지스터 (0x01000001)
//   CHECK3: 계단 지령 10 카운트/창 — 40창 후 |speed - target| <= 2
//   CHECK4: CTRL.clear 후 speed==0, duty==0
`timescale 1ns/1ps
`define SPEED_PI_BASE 32'h1002_0000

module tb_speed_pi;
    // ----- 클럭/리셋 -----
    reg clk, rst;
    initial clk = 0;
    always #5 clk = ~clk; // 100 MHz

    // ----- soc_top 포트 -----
    reg         m_valid;
    reg         m_we;
    reg  [31:0] m_addr;
    reg  [31:0] m_wdata;
    wire [31:0] m_rdata;
    wire        m_ready;
    wire [15:0] led;
    wire        uart_tx_pin;
    wire        pwm_out;

    // 엔코더 모델이 구동하는 신호
    reg enc_a, enc_b;

    // ----- soc_top 인스턴스 (WINDOW_CYCLES=1000으로 단축) -----
    soc_top #(
        .WINDOW_CYCLES (1000)
    ) dut (
        .clk         (clk),
        .rst         (rst),
        .m_valid     (m_valid),
        .m_we        (m_we),
        .m_addr      (m_addr),
        .m_wdata     (m_wdata),
        .m_rdata     (m_rdata),
        .m_ready     (m_ready),
        .led         (led),
        .sw          (16'h0000),
        .uart_tx_pin (uart_tx_pin),
        .enc_a       (enc_a),
        .enc_b       (enc_b),
        .pwm_out     (pwm_out)
    );

    // ----- 모터 모델 파라미터 -----
    localparam MAX_SPEED   = 20;   // 최대 카운트/창
    localparam PERIOD_VAL  = 4000;
    localparam TARGET_VAL  = 10;
    localparam KP_VAL      = 16'h0080; // 0.5
    localparam KI_VAL      = 16'h0010; // 0.0625
    localparam MIN_DUTY_VAL = 100;

    // ----- 모터 상태 (실수 모델, 정수 근사) -----
    // speed_fp = 10-bit 고정소수점 (상위 10비트 = 정수 부분, 최대 1023)
    // speed_fp 단위: 1/1024 카운트
    integer speed_fp;    // 1024 단위 (speed_int = speed_fp / 1024)
    integer duty_int;    // 현재 duty (0~PERIOD_VAL)
    integer enc_period;  // 엔코더 펄스 하나의 클럭 수 (클럭/pulse)
    integer enc_timer;   // 엔코더 타이머 카운터
    integer enc_phase;   // 엔코더 위상 카운터 (0~3)

    // ----- MMIO 태스크 -----
    task mmio_write;
        input [31:0] a;
        input [31:0] d;
        begin
            @(posedge clk); #1;
            m_valid <= 1'b1;
            m_we    <= 1'b1;
            m_addr  <= a;
            m_wdata <= d;
            @(posedge clk); #1;
            m_valid <= 1'b0;
            m_we    <= 1'b0;
        end
    endtask

    task mmio_read;
        input  [31:0] a;
        output [31:0] d;
        begin
            @(posedge clk); #1;
            m_valid <= 1'b1;
            m_we    <= 1'b0;
            m_addr  <= a;
            m_wdata <= 32'd0;
            @(posedge clk); #1;
            d       = m_rdata;
            m_valid <= 1'b0;
        end
    endtask

    // ----- 모터 모델 태스크: 창 완료 후 duty 업데이트, speed 갱신 -----
    // 1창 = 1000 클럭. 모터 모델은 창마다 갱신
    task run_window;
        integer i;
        integer pulse_clks;
        integer speed_int_new;
        begin
            // duty 읽기 (PI IP가 창 완료 후 업데이트)
            mmio_read(`SPEED_PI_BASE + 32'h18, duty_int);
            // speed 갱신: speed[k] = 0.8*speed[k-1] + 0.2*(duty/PERIOD)*MAX_SPEED
            // 정수 근사 (1024 스케일)
            speed_int_new = (speed_fp * 819 + (duty_int * MAX_SPEED * 1024 / PERIOD_VAL) * 205) / 1024;
            speed_fp = speed_int_new;
            // 엔코더 펄스 발생: 1창(1000 클럭) 동안 speed_int 개의 4× 에지를 만든다
            // 4체배 → 각 에지 사이 간격 = 1000 / (speed_int * 4) 클럭
            // speed_int = speed_fp / 1024
        end
    endtask

    // ----- 엔코더 펄스 생성: N개의 CW 4× 에지를 만든다 -----
    task gen_enc_pulses;
        input integer n_edges;
        integer i, gap_clk;
        begin
            gap_clk = (n_edges > 0) ? 1 : 0; // 최소 1클럭 간격
            for (i = 0; i < n_edges; i = i + 1) begin
                // 4× CW 위상: (a=1,b=0) → (a=1,b=1) → (a=0,b=1) → (a=0,b=0) 순
                case (enc_phase % 4)
                    0: begin enc_a <= 1; enc_b <= 0; end
                    1: begin enc_a <= 1; enc_b <= 1; end
                    2: begin enc_a <= 0; enc_b <= 1; end
                    3: begin enc_a <= 0; enc_b <= 0; end
                endcase
                enc_phase = enc_phase + 1;
                repeat (gap_clk) @(posedge clk);
            end
        end
    endtask

    // ----- 1창 시뮬레이션: 엔코더 펄스 + 나머지 클럭 -----
    task sim_one_window;
        integer speed_int;
        integer n_edges;
        integer used_clks;
        integer i;
        begin
            speed_int = speed_fp / 1024;
            n_edges   = speed_int * 4; // 4체배
            if (n_edges > 1000) n_edges = 1000;
            used_clks = n_edges;      // 각 에지에 1클럭 소비
            // 에지 발생
            gen_enc_pulses(n_edges);
            // 나머지 클럭 — 창 완료까지 대기
            if (1000 - used_clks > 0)
                repeat (1000 - used_clks) @(posedge clk);
            // 창 완료 후 duty 읽기 및 motor speed 갱신
            run_window;
        end
    endtask

    // ----- 패스/페일 카운터 -----
    integer pass_cnt, fail_cnt;

    // ----- 메인 테스트 -----
    integer window_i;
    reg [31:0] rd_data;
    integer    final_speed;

    initial begin
        // 초기화
        rst     = 1;
        m_valid = 0;
        m_we    = 0;
        m_addr  = 0;
        m_wdata = 0;
        enc_a   = 0;
        enc_b   = 0;
        speed_fp  = 0;
        duty_int  = 0;
        enc_phase = 0;
        pass_cnt  = 0;
        fail_cnt  = 0;

        repeat (5) @(posedge clk);
        rst = 0;
        repeat (3) @(posedge clk);

        // ----- CHECK1: IP_ID -----
        mmio_read(`SPEED_PI_BASE + 32'hFFF0, rd_data);
        if (rd_data !== 32'h53504931) begin
            $display("FAIL CHECK1: IP_ID expected 0x53504931, got 0x%08X", rd_data);
            fail_cnt = fail_cnt + 1;
        end else begin
            $display("PASS CHECK1: IP_ID = 0x%08X", rd_data);
            pass_cnt = pass_cnt + 1;
        end

        // ----- CHECK2: IP_VER -----
        mmio_read(`SPEED_PI_BASE + 32'hFFF4, rd_data);
        if (rd_data !== 32'h01000001) begin
            $display("FAIL CHECK2: IP_VER expected 0x01000001, got 0x%08X", rd_data);
            fail_cnt = fail_cnt + 1;
        end else begin
            $display("PASS CHECK2: IP_VER = 0x%08X", rd_data);
            pass_cnt = pass_cnt + 1;
        end

        // ----- PI 초기화 -----
        mmio_write(`SPEED_PI_BASE + 32'h0014, PERIOD_VAL);
        mmio_write(`SPEED_PI_BASE + 32'h0008, KP_VAL);
        mmio_write(`SPEED_PI_BASE + 32'h000C, KI_VAL);
        mmio_write(`SPEED_PI_BASE + 32'h001C, MIN_DUTY_VAL);
        mmio_write(`SPEED_PI_BASE + 32'h0004, TARGET_VAL);
        mmio_write(`SPEED_PI_BASE + 32'h0000, 32'h1); // enable

        // ----- CHECK3: 40창 후 속도 수렴 -----
        for (window_i = 0; window_i < 40; window_i = window_i + 1) begin
            sim_one_window;
        end
        mmio_read(`SPEED_PI_BASE + 32'h0010, rd_data);
        final_speed = rd_data[15:0];
        if (final_speed < (TARGET_VAL - 2) || final_speed > (TARGET_VAL + 2)) begin
            $display("FAIL CHECK3: speed %0d not within [%0d, %0d] after 40 windows",
                     final_speed, TARGET_VAL - 2, TARGET_VAL + 2);
            fail_cnt = fail_cnt + 1;
        end else begin
            $display("PASS CHECK3: speed=%0d target=%0d (40 windows)", final_speed, TARGET_VAL);
            pass_cnt = pass_cnt + 1;
        end

        // ----- CHECK4: CTRL.clear 후 speed=0, duty=0 -----
        mmio_write(`SPEED_PI_BASE + 32'h0000, 32'h3); // enable + clear
        repeat (5) @(posedge clk);
        mmio_read(`SPEED_PI_BASE + 32'h0010, rd_data);
        if (rd_data[15:0] !== 16'd0) begin
            $display("FAIL CHECK4a: speed after clear = %0d (expected 0)", rd_data[15:0]);
            fail_cnt = fail_cnt + 1;
        end else begin
            mmio_read(`SPEED_PI_BASE + 32'h0018, rd_data);
            if (rd_data[15:0] !== 16'd0) begin
                $display("FAIL CHECK4b: duty after clear = %0d (expected 0)", rd_data[15:0]);
                fail_cnt = fail_cnt + 1;
            end else begin
                $display("PASS CHECK4: speed=0 duty=0 after clear");
                pass_cnt = pass_cnt + 1;
            end
        end

        // ----- 최종 결과 -----
        $display("--- RESULT: PASS %0d / FAIL %0d ---", pass_cnt, fail_cnt);
        if (fail_cnt !== 0)
            $display("FAIL: %0d check(s) failed", fail_cnt);
        else
            $display("PASS: all checks passed");

        $finish;
    end

    // 타임아웃
    initial begin
        #10_000_000; // 10 ms 시뮬레이션 타임아웃
        $display("FAIL: simulation timeout");
        $finish;
    end
endmodule
